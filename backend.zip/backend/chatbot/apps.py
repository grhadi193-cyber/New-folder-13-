from django.apps import AppConfig


class ChatbotConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "chatbot"
    verbose_name = "چت‌بات"

    def ready(self):
        import chatbot.signals  # noqa: F401
